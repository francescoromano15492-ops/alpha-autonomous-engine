# ALPHA — PROJECT HANDOFF / RESUME FILE

**Last updated:** 21 September 2026  
**Owner:** Francesco  
**Purpose:** Re-upload this file into ChatGPT if chat history is lost. It contains the full working context needed to resume the Alpha autonomous paper-trading project from the current point.

---

## 1. MAIN OBJECTIVE

Build an autonomous trading research + paper-trading system that can run 24/7, discover a genuine statistical edge, and only later consider real-money execution.

The current priority is **not** to force trades or optimize for a daily profit target. The priority is:

1. find an edge that survives realistic costs;
2. validate it out-of-sample with walk-forward testing;
3. forward-test it in paper trading;
4. keep strict deterministic risk controls;
5. only after enough evidence, consider any real-money implementation.

The user previously mentioned an aspirational target of about €100/day, but this must never be treated as guaranteed or assumed achievable.

---

## 2. SAFETY / RISK PRINCIPLES

- PAPER TRADING ONLY for now.
- No live broker/exchange order route exists.
- No real money is connected.
- No API secrets should ever be committed to GitHub.
- If API keys are added later, store them only in Railway Variables/Secrets.
- AI/research logic must never be allowed to loosen risk rules autonomously.
- Do not increase risk merely to create more trades.
- Do not confuse backtest profitability with a real edge.
- Full-sample winners are hypothesis generators; out-of-sample and forward performance matter more.
- Stop losses do not guarantee exact execution price because of gaps/slippage.
- Leverage is only capital efficiency; it does not justify increasing risk per trade.
- No averaging down.

Current live-paper risk rules:
- Risk per trade: **0.20%**
- Max daily loss: **1.5%**
- Max portfolio heat: **1.25%**
- Max gross leverage: **2.0x**
- Max positions: **10**
- Max position notional: **35%**
- Correlation threshold: **0.85**
- Max correlated positions: **3**
- Long-only live engine
- Mandatory stop + target
- Breakeven/trailing logic
- Stale exits
- Funding stress modeled
- Current conservative trading-cost model:
  - Fee: **40 bps each side**
  - Slippage: **5 bps each side**
  - Funding stress: **1 bp / 8h**
  - Minimum net RR: **1.25**
  - Minimum net target: **10 bps**

---

## 3. INFRASTRUCTURE

### GitHub
Repository:
`francescoromano15492-ops/alpha-autonomous-engine`

Important:
- The GitHub connector can READ the repo.
- Direct writes from ChatGPT have repeatedly failed with:
  `403 Resource not accessible by integration`
- Therefore code updates are usually created as a file and manually uploaded/replaced by Francesco.
- Main application file must be named:
  `app.py`

### Railway
Project appears to be named:
`supportive-insight`

Service:
`web`

Public dashboard:
https://web-production-16997.up.railway.app/

Status API:
https://web-production-16997.up.railway.app/api/status

Persistent Railway volume:
- Volume name: `web-data`
- Mounted at: `/data`

SQLite database:
`/data/alpha_v1.db`

Persistent state ID observed:
`35c5f79a214e47fd`

Important:
- Persistence is confirmed.
- Do not repeatedly restart/redeploy without reason.
- If deploy is successful, open the dashboard and let research finish.
- If it crashes, inspect the final logs.

### Environment note
An old variable exists:
`ALPHA_MAX_POSITIONS=5`

From v1.3 onward the code intentionally uses:
`ALPHA_V13_MAX_POSITIONS`

Default:
`10`

This prevents the old environment variable from silently capping the engine.

---

## 4. PYTHON / APP REQUIREMENTS

`requirements.txt`

- fastapi>=0.115
- uvicorn[standard]>=0.30
- pandas>=2.2
- numpy>=2.0
- requests>=2.32

`Procfile`

`web: uvicorn app:app --host 0.0.0.0 --port $PORT --workers 1`

`railway.json`

Uses the same start command and restart-on-failure behavior.

Database schema includes:
- account
- positions
- trades
- signals
- kv

Later migrations added:
- initial_stop_price
- best_price
- funding

---

## 5. LIVE PAPER ENGINE — CURRENT STRUCTURE

Markets:
25 Kraken crypto markets:

XBTUSD, ETHUSD, SOLUSD, XRPUSD, ADAUSD, DOGEUSD, LINKUSD, LTCUSD,
AVAXUSD, DOTUSD, BCHUSD, ATOMUSD, XLMUSD, UNIUSD, AAVEUSD, ETCUSD,
ALGOUSD, NEARUSD, FILUSD, ICPUSD, INJUSD, SUIUSD, ARBUSD, OPUSD, TRXUSD

Timeframes:
- 5m
- 15m
- 60m

Historical/live strategy families used in the older live engine:
- fast_breakout
- donchian_10_breakout
- rsi_reclaim_fast
- trend_pullback
- ema9_momentum
- bollinger_reentry_fast

Live engine remains long-only.

Exit management:
- +1R -> stop raised above fee break-even
- +1.5R -> stop raised to about +0.5R
- stale exits:
  - 5m: 72 bars
  - 15m: 48 bars
  - 60m: 24 bars

---

## 6. VERSION HISTORY AND FINDINGS

### Alpha v1.0
First autonomous 24/7 paper engine.

Originally:
- 7 Kraken crypto symbols
- 3 timeframes

Main lesson:
Railway redeploys originally reset SQLite because storage was ephemeral.

Fix:
Persistent Railway volume `/data`.

---

### Alpha v1.1 — Cost-aware engine

Defaults:
- risk/trade 0.25%
- daily loss 1.5%
- heat 1.25%
- max positions 5
- gross exposure 80%
- max notional 20%
- fee 40bps each side
- slippage 5bps each side
- min net RR 1.5

Round-trip modeled cost was roughly 90bps.

Main lesson:
Many short-timeframe opportunities were economically invalid after costs.

We deliberately did NOT lower thresholds just to force trades.

---

### Alpha v1.2 — Active Intraday 24/7 Paper Engine

Expanded to:
- 25 Kraken crypto markets
- 5/15/60m
- 6 strategy families

Risk:
- 0.20% per trade
- max daily loss 1.5%
- max heat 1.25%
- initially max 5 positions

It successfully opened 5 positions and demonstrated the risk governor.

Initial positions included:
- DOTUSD 60m fast_breakout
- UNIUSD 60m rsi_reclaim_fast
- NEARUSD 60m fast_breakout
- FILUSD 60m rsi_reclaim_fast
- SUIUSD 60m fast_breakout

Later INJUSD trend_pullback opened, bringing total to 6.

---

### Alpha v1.3 — Ranked Edge + 2x Paper Engine

Added:
- max 10 positions
- max gross leverage 2x
- risk per trade unchanged at 0.20%
- candidate ranking
- correlation guard
- mandatory stop
- breakeven/trailing
- stale exit
- funding stress

Important:
Heat at 1.25% remained the true portfolio bottleneck.

Research at the time was too shallow and showed no reliable edge.

---

### Alpha v1.4 — Deep Research + Walk-Forward

Goal:
90-day deep research over:
- first 12 markets
- 5/15/60m
- fixed strategies
- 3-fold expanding walk-forward

Initial problem:
Binance historical public data failed from Railway.

Fallback to Kraken produced:
- poor coverage
- only about 39 trades

Conclusion:
Data-source failure, not a valid deep test.

---

### Alpha v1.4.1 — Bitstamp historical source

Changed deep research:
- Bitstamp public OHLC primary
- Kraken fallback

Observed results:
- Historical trades: 137
- Avg R: about -0.326
- Win rate: 27.7%
- Profit factor: about 0.42
- Max DD: about 46.89R
- Evidence:
  `INSUFFICIENT_EDGE_EVIDENCE`
- Deep coverage:
  100%

Strategy breakdown at that point:

fast_breakout:
- 40 trades
- Avg R around +0.013 to +0.035 depending later refresh
- PF around 1.03–1.08

bollinger_reentry_fast:
- 12 trades
- Avg R -0.1392
- PF 0.667

donchian_10_breakout:
- 44 trades
- Avg R -0.3795
- PF 0.382

rsi_reclaim_fast:
- 19 trades
- Avg R -0.6323
- PF ~0.002

trend_pullback:
- 21 trades
- Avg R -0.6591
- PF ~0.015

ema9_momentum:
- 1 trade
- Avg R about -1

Main lesson:
The data source problem was solved.
The existing strategy set did NOT show a robust edge.

---

### Alpha v1.5 — Research Lab + Cost-Stress Walk-Forward

Purpose:
Systematic parameter search rather than manual tweaking.

It tested parameter combinations across:
- breakout lookback 10/20/40
- trend / strong trend filters
- volume ratio 0.8 / 1.0
- breakout stop ATR 1.2 / 1.6
- breakout target ATR 2.4 / 3.2
- RSI reclaim variants
- trend pullback variants
- 5/15/60m
- 3 cost profiles

Cost profiles:

1. current_40fee_5slip
   - fee 40bps each side
   - slippage 5bps each side
   - funding 1bp/8h

2. mid_20fee_4slip
   - fee 20bps
   - slippage 4bps
   - funding 1bp/8h

3. lean_10fee_3slip
   - fee 10bps
   - slippage 3bps
   - funding 0.5bp/8h

Observed v1.5 research:
- Trade rows: 85,159+
- Candidates: 515
- Evidence:
  `NO_ROBUST_EDGE_YET`

Best current-cost full-sample candidate:
`breakout_L40_trend_V1.0_S1.6_T3.2`
- 60m
- 25 trades
- Avg R roughly +0.075 to +0.106
- PF roughly 1.19–1.27
- Total R roughly +1.9 to +2.65

But walk-forward:
- OOS trades: 28
- OOS Avg R: -0.355
- OOS PF: 0.449
- OOS Total R: -9.94
- Profitable folds: 0/3

Main lesson:
The full-sample “winner” did NOT generalize.
Do not keep optimizing the same families.

---

### Alpha v1.6 — Regime + Relative Strength Edge Explorer

Purpose:
Test genuinely different sources of edge.

Added research-only:
- simulated long + short
- BTC regime detection
- regime breakout
- relative strength / relative weakness
- sideways mean reversion
- multi-timeframe 60m -> 15m
- cross-sectional momentum

Live engine stayed unchanged.

Observed v1.6 Edge Explorer:
- Trade rows: 1,701
- Candidates: 19
- Evidence:
  `NO_ROBUST_EDGE_YET`

Most interesting result:
**relative strength / relative weakness**

Best current-cost candidate:
`relative_strength_24h_long`
- 60m
- current_40fee_5slip
- 20 trades
- Avg R: +0.1343
- Win rate: 50%
- PF: 1.318
- Total R: +2.69
- Max DD: 7.29R

Best mid-cost:
`relative_weakness_24h_short`
- 60m
- 47 trades
- Avg R: +0.1432
- Win rate: 53.2%
- PF: 1.349
- Total R: +6.73
- Max DD: 6.21R

Current-cost family aggregate:
relative_strength
- 24 trades
- Avg R: +0.1381
- Win rate: 50%
- PF: 1.384
- Total R: +3.31

However:
Edge walk-forward had:
- 0 eligible candidates
- 0 OOS trades
- 0/3 profitable folds

Reason:
Not enough sample / training eligibility yet.

Main lesson:
Relative strength is the first genuinely promising direction, but it is NOT yet validated.

---

## 7. LIVE PAPER RESULT OBSERVED

First closed live-paper trade:

SUIUSD
- timeframe: 60m
- strategy: fast_breakout
- exit reason: TARGET
- net P&L: **+$32.30**
- R multiple: **+1.6166R**
- fees: **$4.31**
- funding: **$0.05**

At the same snapshot:
- Equity: about **$9,998.79**
- Net realized P&L: **+$32.30**
- Closed trades: 1
- Win rate: 100% (meaningless sample of 1)
- Open positions: 5
- Gross leverage: 0.27x
- Heat: about 0.999%

Important:
The positive closed trade is encouraging operationally, but it is NOT statistical evidence of profitability.

---

## 8. CURRENT VERSION — ALPHA v1.7

Current active version:

**Alpha v1.8.1 — Architecture Sanity + Kraken Cost Model**

GitHub was verified after upload:
`APP_VERSION = "Alpha v1.7 — Relative Strength Specialist + 180d Walk-Forward"`

Purpose:
Deeply test the only strategy family that showed a promising signal in v1.6.

v1.7 research focus:
- Relative strength
- Relative weakness
- 180 days of history
- up to 25 markets
- primarily 60m research
- windows:
  - 12h
  - 24h
  - 48h
  - 72h
- 5-fold walk-forward
- training-only selection
- maximum one long and one short strategy per fold to reduce correlated stacking
- cost stress retained
- no automatic live promotion

Important design rule:
For the 180d specialist study, use only markets with sufficiently complete deep history.
Do NOT pad incomplete 180d history with short Kraken history, because that would distort the sample.

Expected new dashboard section:
`v1.7 Relative Strength Specialist — 180d`

Current status at time of this handoff:
- v1.7 is deployed and active.
- Waiting for the 180d research + 5-fold walk-forward to finish.
- Next action is to inspect a new dashboard snapshot / saved `.mht`.

Dashboard:
https://web-production-16997.up.railway.app/

---

## 9. WHAT TO CHECK NEXT IN v1.7

When the next `.mht` or screenshot is provided, inspect especially:

1. Specialist state
2. Number of eligible markets with full 180d history
3. Total specialist trade rows
4. Number of candidates
5. Best full-sample candidates by cost profile
6. Relative-strength vs relative-weakness results
7. Results by 12h / 24h / 48h / 72h lookback
8. 5-fold walk-forward:
   - OOS trades
   - OOS Avg R
   - OOS Profit Factor
   - OOS Total R
   - profitable folds / 5
9. Whether positive performance survives the conservative current-cost profile
10. Whether results remain positive across multiple nearby lookbacks rather than one isolated parameter

Do NOT promote anything simply because full-sample metrics look good.

---

## 10. PROMOTION LOGIC / DECISION STANDARD

A strategy should remain research-only unless:

- enough trades exist;
- Avg R is positive;
- Profit Factor is meaningfully above 1;
- drawdown is acceptable;
- multiple nearby parameterizations are not collapsing;
- walk-forward OOS is positive;
- more than one fold is profitable;
- results survive realistic/current intended venue costs;
- forward paper trading confirms historical evidence.

If cheaper cost scenarios work but current conservative costs do not:
Do NOT simply reduce costs in the model to make results look better.

Instead:
1. choose the actual intended exchange/broker;
2. use its documented fee structure;
3. measure realistic slippage;
4. then rerun the tests using the real cost model.

---

## 11. EMAIL DELIVERY

Francesco's email used successfully for project files:

`francescoromano15492@gmail.com`

Files already successfully sent by email in the past:
- Alpha v1.4
- Alpha v1.4.1
- Alpha v1.5
- Alpha v1.6

If Francesco explicitly asks:
“mandamelo per mail”
that is sufficient authorization to send the current generated file to the above address.

---

## 12. WORKING STYLE / USER PREFERENCE

Francesco is doing most setup from Android and does not want complicated multi-step technical instructions.

Important interaction rules:
- Give one simple action at a time.
- Avoid unnecessary navigation.
- Always include the direct dashboard link when asking him to inspect it:
  https://web-production-16997.up.railway.app/
- If a download from ChatGPT fails on mobile, email delivery is a good fallback.
- Do not ask him to install Python on his company PC.
- Do not tell him to bypass company/device restrictions.
- Avoid sending him repeatedly through GitHub/Railway menus unless necessary.
- If GitHub upload is needed, tell him simply:
  “replace the current file and name it exactly `app.py`”.
- If deployment is successful, stop changing things and let the research run.

---

## 13. HOW TO RESUME IF THIS FILE IS RE-UPLOADED

If this file is uploaded into a new ChatGPT conversation, the assistant should:

1. Treat this file as the canonical project handoff.
2. Ask for the latest dashboard `.mht` or screenshot only if it is not already attached.
3. Confirm whether GitHub still contains the expected version if needed.
4. Do NOT restart from v1.0.
5. Do NOT rebuild infrastructure from scratch.
6. Continue from the latest active stage:
   **Alpha v1.8.1 — Architecture Sanity + Kraken Cost Model**
7. First task:
   analyze v1.7 results and determine whether relative strength / weakness finally shows robust OOS evidence.
8. Keep live engine in paper mode unless strong evidence accumulates.
9. Never claim guaranteed profitability.

---

## 14. QUICK RESUME BLOCK

If only a short summary is needed:

- Repo: `francescoromano15492-ops/alpha-autonomous-engine`
- Main file: `app.py`
- Railway dashboard:
  https://web-production-16997.up.railway.app/
- Persistent DB:
  `/data/alpha_v1.db`
- Current version:
  **Alpha v1.8.1 — Architecture Sanity + Kraken Cost Model**
- Live mode:
  PAPER ONLY
- Current risk:
  0.20%/trade, 1.5% daily loss, 1.25% heat, 2x gross max
- Most promising research so far:
  **relative strength / relative weakness**
- v1.6 best current-cost result:
  relative_strength_24h_long, 20 trades, Avg R +0.1343, PF 1.318
- But v1.6 had 0 valid OOS trades due insufficient eligible sample
- v1.7 expands to:
  180d, up to 25 markets, 12/24/48/72h windows, 5-fold WFO
- Next action:
  inspect v1.7 specialist OOS results once complete.

---

END OF HANDOFF FILE

---

## 15. UPDATE — ALPHA v1.8 RESULTS

Alpha v1.8 was deployed and completed.

Purpose:
- 180d multi-regime / multi-family architecture
- same-entry cost stress
- 5-fold outer walk-forward
- paper only

Observed v1.8 live snapshot:
- Equity: about $10,043.10
- Realized net P&L: +$32.30
- Closed trades: 1
- Open positions: 6
- Gross leverage: 0.33x
- Heat: about 1.194%
- New live paper position opened: OPUSD 60m / rsi_reclaim_fast
- NEARUSD stop had moved above entry, meaning profit protection had activated

Key v1.8 architecture findings:
- 24/25 deep markets
- 6,153 raw trades
- 18,459 paired-cost rows under the original 3 scenarios
- Cost pairing audit: EXACT
- No current-cost family showed a robust edge
- 5-fold outer walk-forward:
  - 0 eligible candidates in every fold
  - 0 OOS trades
  - 0/5 profitable folds
  - no OOS survivor families
- Evidence:
  `NO_ROBUST_MULTI_FAMILY_EDGE_YET`

Important cost observation from identical 1,040 relative-strength trades:
- 40bps fee + 5bps slippage:
  Avg R about -0.3013, PF about 0.637
- 20bps fee + 4bps slippage:
  Avg R about -0.0637, PF about 0.908
- 10bps fee + 3bps slippage:
  Avg R about +0.0638, PF about 1.103

This showed that execution economics materially affect the apparent edge.

Critical v1.8 issue discovered:
`arch_xsec_momentum_long` produced absurdly large negative R values (billions / tens of billions of R), which is not a plausible market result and indicates a numerical denominator problem.

Likely cause:
The cross-sectional family did not apply the same minimum ATR/volatility floor used by the other architecture families, allowing microscopic structural-risk denominators.

Decision:
Do not use the affected cross-sectional v1.8 figures for strategy conclusions.
Create v1.8.1 to clean methodology first.

---

## 16. CURRENT BUILD — ALPHA v1.8.1

Current build being prepared:

**Alpha v1.8.1 — Architecture Sanity + Kraken Cost Model**

Changes:
- Live paper engine remains unchanged.
- Cross-sectional momentum now must pass the same minimum ATR-percent filter as other architecture families.
- All architecture raw trades now require a minimum structural-risk denominator.
- Pathological / non-finite R-multiples are explicitly rejected rather than ranked.
- Maximum absolute accepted architecture R-multiple defaults to 10R as a numerical sanity guard.
- Cost-pair audit is performed on the full cost-expanded raw-trade set.
- Valid rows and sanity-rejected rows are reported separately.
- Architecture evidence baseline is now a venue-aware Kraken reference cost profile.
- Older labs remain intact for comparability.

v1.8.1 architecture sanity defaults:
- Minimum ATR %: 0.5%
- Minimum structural risk: 50 bps
- Maximum absolute R for architecture research: 10R

v1.8.1 architecture cost overlays:
1. `kraken_t1_all_taker`
   - entry fee 80 bps
   - exit fee 80 bps
   - 5 bps entry/exit slippage assumption
   - used as conservative evidence baseline

2. `kraken_t1_taker_entry_maker_target`
   - entry taker 80 bps
   - target maker 40 bps
   - stop/time taker 80 bps
   - target modeled with 0 bps slippage, other executions with 5 bps
   - diagnostic only

3. `kraken_t3_all_taker`
   - 38 bps each side
   - 5 bps slippage assumption
   - diagnostic only

4. `research_lean_10fee_3slip`
   - synthetic low-cost stress case
   - not a venue claim

Important:
Kraken fees are only a reference model at this stage. Final venue/execution mechanics are not locked.
Maker fills are not guaranteed.
Slippage and funding assumptions remain research assumptions.

v1.8.1 validation already performed locally:
- Python syntax compile: passed
- Import test: passed
- Cost-pair invariant test: passed
- Pathological tiny-risk R sanity rejection: passed
- Full synthetic architecture smoke test:
  - 1,415 raw trades
  - 5,660 cost rows across 4 profiles
  - exact 1,415 rows per profile
  - cost pairing exact
  - no sanity-rejected rows in the synthetic normal-volatility sample
  - architecture completed successfully

Next action after deploy:
Inspect the v1.8.1 Architecture section and verify:
- Cost pairing = EXACT
- Sanity rejected rows are 0 or explainable
- No absurd R-multiples remain
- Results under `kraken_t1_all_taker`
- Results under mixed maker/taker reference profile
- WFO candidate eligibility and OOS results
---

## 17. LATEST CURRENT BUILD — ALPHA v1.9

This section supersedes earlier sections labeled "CURRENT BUILD".

Current build:

**Alpha v1.9 — Low-Turnover Execution Edge + Spot/Futures Cost Stress**

Why v1.9 exists:
v1.8.1 showed that the existing higher-turnover signals remain negative under realistic venue costs, while cheaper execution materially improves them. The next research question is therefore not "add more indicators", but whether wider, slower trades can produce enough gross movement to survive realistic execution costs.

Live paper engine:
- unchanged
- still long-only
- still paper only
- no futures order route
- no live short route
- no real-money execution
- existing risk controls unchanged

v1.9 research design:
- Separate report-only research layer
- Target history: 365 days
- Target markets: first 12 liquid markets from the current universe
- Source: Bitstamp 60m deep history
- Synthetic research bars built locally from completed 60m candles:
  - 4h
  - 12h
- Low-turnover families:
  - 4h slow breakout
  - 4h slow pullback
  - 12h macro breakout
  - 12h macro pullback
- Wider structural stops and targets than the intraday live engine
- Typical research holding windows: about 3–10 days
- Same raw signals, entries and exits are cloned across every cost scenario
- 5-fold expanding walk-forward
- Selection uses training data only
- Maker-fill scenarios are diagnostic only

v1.9 execution cost profiles:
1. `kraken_spot_t1_all_taker`
   - 80 bps fee per side
   - 5 bps slippage assumption per side
   - no funding

2. `kraken_spot_t3_all_taker`
   - 38 bps fee per side
   - 5 bps slippage assumption per side
   - no funding

3. `kraken_futures_t1_all_taker_funding1`
   - 5 bps fee per side
   - 3 bps slippage assumption per side
   - 1 bp / 8h constant funding stress

4. `kraken_futures_t1_all_taker_funding5`
   - 5 bps fee per side
   - 3 bps slippage assumption per side
   - 5 bps / 8h constant funding stress
   - this is the conservative v1.9 evidence baseline

5. `kraken_futures_t1_maker_entry_target_funding1`
   - 2 bps maker entry
   - 2 bps maker target
   - 5 bps taker stop/time exit
   - maker entry/target slippage modeled as 0
   - 1 bp / 8h funding stress
   - diagnostic only because maker fills are not guaranteed

Important methodology notes:
- Kraken derivatives Tier-1 maker/taker inputs are 2/5 bps.
- Kraken spot Tier-1 maker/taker inputs are 40/80 bps; v1.9 all-taker spot uses 80 bps each side.
- Historical futures funding is NOT available in this engine.
- Funding is therefore stress-tested as a constant cost, not backfilled as if it were historical truth.
- Spot-cost rows for simulated shorts are only cost-sensitivity diagnostics. A real plain-spot short route would require separate borrow/margin mechanics.
- Evidence cannot be promoted solely because a maker-fill scenario looks attractive.

v1.9 evidence gate:
`EXECUTION_EDGE_CANDIDATE` requires all of:
- exact cost pairing
- enough deep markets
- best conservative futures-stress candidate >= 50 trades
- positive Avg R
- PF > 1.10
- >= 50 OOS trades
- positive OOS Avg R
- OOS PF > 1.05
- at least 3/5 profitable OOS folds

Otherwise:
`NO_ROBUST_EXECUTION_EDGE_YET`

New endpoint:
`/api/execution-edge`

New dashboard section:
`v1.9 Low-Turnover Execution Edge — 365d`

Local validation completed before deployment:
- Python syntax: passed
- import: passed
- endpoint `/api/execution-edge`: present
- 5 execution cost profiles loaded
- synthetic 8-market / ~365d dry-run:
  - 1,207 raw trades
  - 6,035 paired cost rows
  - exactly 1,207 rows under each of 5 cost profiles
  - cost pairing EXACT
  - 12 primary candidates
  - 5-fold WFO completed
- Synthetic performance numbers are functional tests only and are NOT evidence of a real market edge.

Next action after deployment:
1. Verify GitHub APP_VERSION is Alpha v1.9.
2. Let Railway complete the older research pipeline and then the separate 365d execution-edge download/test.
3. Open:
   https://web-production-16997.up.railway.app/
4. Wait until the v1.9 execution section is `done`.
5. Save/upload the `.mht`.
6. Inspect first:
   - deep market coverage
   - cost pairing EXACT
   - best conservative futures-stress candidate
   - spot vs futures same-entry comparison
   - OOS trades / Avg R / PF / Total R
   - profitable folds / 5
   - whether any candidate survives funding stress rather than only the maker diagnostic.

---

## 18. LATEST QUICK RESUME

- Repo: `francescoromano15492-ops/alpha-autonomous-engine`
- Main file: `app.py`
- Railway dashboard:
  https://web-production-16997.up.railway.app/
- Persistent DB:
  `/data/alpha_v1.db`
- Latest build:
  **Alpha v1.9 — Low-Turnover Execution Edge + Spot/Futures Cost Stress**
- Live mode:
  PAPER ONLY
- Live engine:
  unchanged from prior versions
- Research priority:
  determine whether slower 4h/12h trades with wider targets can survive realistic execution costs
- Evidence baseline:
  Kraken derivatives Tier-1 all-taker reference + harsh 5 bp/8h funding stress
- Maker scenarios:
  diagnostic only
- Next task:
  analyze the completed v1.9 `.mht`; do not promote to real money from historical results alone.

---

## 19. REAL v1.9 RESULT — 2026-09-21

Uploaded dashboard artifact: `Alpha v1.9.mht`.

v1.9 completed correctly.

Core execution-research result:
- 365d low-turnover research completed.
- Deep market coverage: 11/12.
- Raw trades: 1,677.
- Five same-entry cost profiles produced 8,385 paired cost rows.
- Cost pairing: EXACT.
- Evidence gate: `NO_ROBUST_EXECUTION_EDGE_YET`.

Most interesting full-sample candidate under the deliberately harsh primary futures profile
`kraken_futures_t1_all_taker_funding5`:
- `exec_4h_breakout40_short`
- 191 trades
- Avg R +0.1095
- PF 1.198
- Total +20.92R

Same candidate under the milder futures all-taker funding1 profile:
- Avg R +0.2088
- PF 1.409
- Total +39.89R

Macro-breakout family under the primary cost profile:
- 232 trades
- Avg R +0.0635
- PF 1.136
- Total +14.73R

However the 5-fold execution walk-forward FAILED:
- OOS trades: 230
- OOS Avg R: -0.355
- OOS PF: 0.49
- OOS Total: -81.65R
- Profitable folds: 1/5

OOS family diagnostics:
- macro_breakout: 58 trades, Avg R -0.0318, PF 0.936, Total -1.85R, 1 profitable fold
- slow_breakout: 73 trades, Avg R -0.5093, PF 0.37, Total -37.18R
- slow_pullback: 99 trades, Avg R -0.4305, PF 0.416, Total -42.62R

One isolated positive fold existed for `exec_12h_breakout20_short`:
- fold 3
- 25 test trades
- Avg R +0.742
- PF 4.562
- Total +18.55R
This did NOT persist across the other folds and therefore is not treated as validated edge.

Interpretation:
- v1.9 produced the first genuinely interesting low-turnover full-sample signals that survive realistic futures-style cost stress.
- The signals still fail robust OOS validation.
- Do NOT promote them to real money.
- Do NOT keep parameter-mining the same historical sample.
- The appropriate next step is true forward shadow collection.

Live paper snapshot at the v1.9 artifact:
- Equity ~$10,037.71
- Realized P&L +$32.30
- Closed live trades: 1
- Open live positions: 6
- Gross leverage ~0.33x
- NEARUSD fast_breakout had entry 4.15037415, protected stop ~4.24088631, last ~4.4078 at snapshot.

---

## 20. CURRENT BUILD — ALPHA v2.0

Current build:

**Alpha v2.0 — Shadow Forward Lab**

Purpose:
Stop optimizing historical data and collect genuinely unseen forward evidence on the two most interesting frozen v1.9 candidates.

Frozen shadow strategies:
1. `exec_12h_breakout20_short`
   - family: macro_breakout
   - 12h synthetic bars
   - short only
   - strong downtrend condition from v1.9
   - close below prior 20-bar low
   - stop = 2.5 ATR
   - target = 7.0 ATR
   - max hold = 20 x 12h = 240h / 10 days

2. `exec_4h_breakout40_short`
   - family: slow_breakout
   - 4h synthetic bars
   - short only
   - strong downtrend condition from v1.9
   - close below prior 40-bar low
   - volume ratio >= 0.80
   - stop = 2.5 ATR
   - target = 6.5 ATR
   - max hold = 42 x 4h = 168h / 7 days

Critical anti-overfit rules:
- No parameter optimization in v2.0.
- Strategies are frozen from v1.9 before forward collection begins.
- Forward start timestamp is persisted on first v2.0 startup.
- Signals completed before that timestamp are ignored.
- No historical backfill after a restart/outage.
- One open shadow position per strategy/symbol.
- Shadow positions never touch the live paper account.
- No real order route exists.

Data / monitoring:
- Signal history: Bitstamp public 60m deep history, 150d by default, resampled to 4h/12h.
- Signal scan only when a new 4h UTC bucket begins, avoiding constant deep downloads.
- Open shadow positions are monitored every ~5 minutes by default.
- Stop/target monitoring uses completed Kraken 1m candles plus current ticker protection.
- State persists in the existing SQLite database `/data/alpha_v1.db`.

Persistent new tables:
- `shadow_positions`
- `shadow_trades`
- `shadow_signals`

Forward cost overlays on the SAME shadow trade:
- primary: `kraken_futures_t1_all_taker_funding5`
- alternative: `kraken_futures_t1_all_taker_funding1`
- maker diagnostic: `kraken_futures_t1_maker_entry_target_funding1`

Stored forward metrics per closed shadow trade:
- gross R
- primary-cost R
- funding1 R
- maker-diagnostic R
- actual forward holding hours
- exit reason

Forward evidence status:
- `FORWARD_SAMPLE_BUILDING` by default.
- A frozen strategy can become a `FORWARD_EVIDENCE_CANDIDATE` only after at least 30 forward days, at least 50 closed forward shadow trades for that individual strategy, positive Avg R, and PF > 1.10 under the harsh primary all-taker + funding5 profile.
- Candidate strategy IDs are reported explicitly.
- Even this status is NOT automatic permission to trade real money.

New APIs:
- `/api/shadow-forward`
- `/api/shadow-positions`
- `/api/shadow-trades`
- `/api/shadow-signals`

Dashboard:
- New `v2.0 Shadow Forward Lab` section showing forward start, age, open/closed shadow trades, primary/alternative/maker performance, frozen-strategy breakdown, open shadow positions, recent shadow trades, recent shadow signals.

Local validation before deployment:
- Python compile: PASS
- Import: PASS
- New shadow routes: PASS
- New SQLite tables: PASS
- Synthetic frozen 4h short breakout signal: PASS
- Shadow open -> target close -> cost overlays -> persistent trade: PASS
- Live paper engine/risk logic was not changed by the v2.0 shadow module.

Next action:
1. Deploy `alpha_v2_0_ready.py` as GitHub `app.py`.
2. Verify the dashboard header reads `Alpha v2.0 — Shadow Forward Lab`.
3. Then leave it running. There is no need to wait for an immediate backtest result: forward evidence intentionally starts from deployment onward.
4. Check the Shadow Forward section over the coming days/weeks. The first signal may not occur immediately.

---

## 21. LATEST QUICK RESUME

- Repo: `francescoromano15492-ops/alpha-autonomous-engine`
- Main file: `app.py`
- Railway dashboard: https://web-production-16997.up.railway.app/
- Persistent DB: `/data/alpha_v1.db`
- Latest build to deploy: **Alpha v2.0 — Shadow Forward Lab**
- Main live paper engine: unchanged
- Real orders: NONE
- Live shorts: NONE
- Shadow shorts: simulated only
- Frozen forward candidates: `exec_12h_breakout20_short`, `exec_4h_breakout40_short`
- Forward data: starts only after first v2.0 startup, no backfill
- Primary forward cost stress: futures Tier-1 reference, all-taker + 5bp/8h funding stress
- Main objective now: accumulate unseen forward evidence instead of historical parameter mining.

---

## 19. REAL v1.9 RESULTS — 2026-09-21

Uploaded report: `Alpha v1.9.mht`.

Key execution-edge results:
- 365d research completed.
- Deep markets: 11/12.
- Raw trades: 1,677.
- Paired cost rows: 8,385 = exactly 1,677 x 5 cost profiles.
- Cost pairing: EXACT.
- Evidence gate: `NO_ROBUST_EXECUTION_EDGE_YET`.

Promising full-sample clue under conservative futures stress:
- `exec_4h_breakout40_short`
- 191 trades
- Avg R +0.1095
- PF 1.198
- Total +20.92R
- This survives the harsh research profile with all-taker futures costs + 5bp/8h funding stress.

Under lighter 1bp/8h funding stress the same strategy improved to approximately:
- Avg R +0.2088
- PF 1.409
- Total +39.89R

Macro breakout family under primary cost:
- 232 trades
- Avg R +0.0635
- PF 1.136
- Total +14.73R

But the 5-fold walk-forward failed overall:
- OOS trades: 230
- OOS Avg R: -0.355
- OOS PF: 0.49
- OOS Total: -81.65R
- Profitable folds: 1/5

OOS family diagnostics:
- macro_breakout: 58 trades, Avg R -0.0318, PF 0.936, Total -1.85R, 1 profitable fold
- slow_breakout: 73 trades, Avg R -0.5093, PF 0.37, Total -37.18R
- slow_pullback: 99 trades, Avg R -0.4305, PF 0.416, Total -42.62R

One isolated fold was strong for `exec_12h_breakout20_short`:
- Fold 3: 25 trades, Avg R +0.742, PF 4.562, Total +18.55R.
- Other periods did not confirm it.

Interpretation:
- Do not promote v1.9 strategies to live/real money.
- The only hypotheses worth freezing for forward observation are:
  1. `exec_12h_breakout20_short`
  2. `exec_4h_breakout40_short`
- Stop parameter-mining them. Collect genuinely unseen forward evidence instead.

Live paper snapshot in the v1.9 report:
- Equity about $10,037.71
- Realized P&L +$32.30
- Closed trades 1
- Open positions 6
- Gross leverage ~0.33x
- Heat ~1.195%
- NEAR stop had been raised above entry, locking paper profit if hit.

---

## 20. CURRENT BUILD — ALPHA v2.0 SHADOW FORWARD LAB

Current build:
**Alpha v2.0 — Shadow Forward Lab**

Local artifact:
`/mnt/data/alpha_v2_0_ready.py`

Purpose:
Stop optimizing the two most interesting v1.9 hypotheses and observe them prospectively on future data that did not exist when the hypotheses were selected.

Live engine:
- unchanged
- paper only
- long-only live engine remains separate
- no real-money route
- no live short route
- no shadow position can affect account cash/equity/risk/slots

Frozen shadow strategies:
1. `exec_12h_breakout20_short`
   - 12h bars
   - strong downtrend condition inherited from v1.9
   - close below prior 20-bar low
   - stop 2.5 ATR
   - target 7.0 ATR
   - maximum hold 20 x 12h = 240h

2. `exec_4h_breakout40_short`
   - 4h bars
   - strong downtrend condition inherited from v1.9
   - close below prior 40-bar low
   - volume ratio >= 0.80
   - stop 2.5 ATR
   - target 6.5 ATR
   - maximum hold 42 x 4h = 168h

Forward-only protections:
- A persistent `shadow_forward_epoch` is created the first time v2.0 runs.
- Signals whose synthetic bar ended before that epoch are ignored.
- Signals detected more than 20 minutes after the bar close are recorded as `MISSED_STALE` rather than retroactively opened.
- On restart, the epoch remains persistent in SQLite, so past history is not silently converted into forward trades.
- Strategy configuration is hashed and shown in the dashboard for auditability.

Data handling:
- The shadow lab reuses the 365d Bitstamp 60m frames already downloaded by the v1.9 execution research as indicator warm-up; those historical candles are never inserted as shadow trades.
- 4h and 12h bars are rebuilt locally from completed 60m bars.
- Once seeded, the shadow loop refreshes recent completed Kraken 60m OHLC approximately every 15 minutes and merges it into the warm-up cache.
- Shadow entries use the current Kraken public ticker observed shortly after a newly completed qualifying bar.
- Shadow stop/target/time exits are evaluated conservatively from subsequent completed 60m OHLC bars; if stop and target are both touched in one bar, stop wins.

Shadow execution model:
- simulated shorts only
- cost profile frozen to `kraken_futures_t1_all_taker_funding5`
- 5 bps fee each side
- 3 bps slippage each side
- 5 bps/8h funding stress
- entry is simulated at the current observed market price after a newly completed qualifying bar, with adverse short-entry slippage
- stop/target based on the frozen ATR multiples above
- position management runs independently of the main paper account

Persistent SQLite tables added:
- `shadow_positions`
- `shadow_trades`
- `shadow_signals`

New endpoints:
- `/api/shadow-forward`
- `/api/shadow-positions`
- `/api/shadow-trades`

Dashboard section:
- `v2.0 Shadow Forward Lab — forward-only`
- shows days forward, closed trades, open shadow positions, Avg R, PF, Total R, evidence state, strategy hash, strategy-level results and recent shadow trades.

Forward evidence gate:
- remains `FORWARD_COLLECTING` until at least:
  - 60 forward days
  - 50 closed shadow trades
  - positive Avg R
  - PF > 1.10
- then it may become `FORWARD_EVIDENCE_CANDIDATE`.
- This still does NOT mean automatic real-money promotion.

Local validation completed:
- Python syntax compile: passed
- module import: passed
- shadow endpoints present
- persistent shadow tables created successfully
- shadow open/close round-trip unit test passed
- short execution cost/funding/R calculation produced finite values
- live engine code/risk settings were not intentionally changed

Next deployment steps:
1. Upload `alpha_v2_0_ready.py` to the GitHub repo and rename it exactly `app.py`.
2. Verify APP_VERSION says `Alpha v2.0 — Shadow Forward Lab`.
3. Let Railway deploy.
4. The shadow lab starts its forward epoch on first successful v2.0 boot.
5. Do not reset/delete `/data/alpha_v1.db`, otherwise the forward epoch and shadow ledger would be lost.
6. No need to wait for dozens of forward trades immediately. This version is designed to collect evidence over weeks/months.
7. Dashboard remains:
   https://web-production-16997.up.railway.app/


---

## 19. LATEST CURRENT BUILD — ALPHA v2.0

This section supersedes earlier sections labeled CURRENT BUILD.

Current build:

**Alpha v2.0 — Shadow Forward Lab + Persistent OOS Evidence**

Why v2.0 exists:
- v1.9 found the first historically interesting low-turnover hypotheses, especially `exec_4h_breakout40_short` and the 12h macro-breakout family.
- Historical 5-fold OOS was still negative overall, so no strategy is promoted to the live paper engine.
- v2.0 freezes two hypotheses and starts a clean, persistent, forward-only shadow test on future data.

Frozen shadow strategies:
1. `exec_12h_breakout20_short`
   - family: macro_breakout
   - short only
   - 12h synthetic bars
   - strong downtrend: EMA20 < EMA50 < EMA200
   - close below prior 20-bar low
   - stop: 2.5 ATR
   - target: 7.0 ATR
   - max hold: 20 x 12h = 240h / 10 days

2. `exec_4h_breakout40_short`
   - family: slow_breakout
   - short only
   - 4h synthetic bars
   - strong downtrend: EMA20 < EMA50 < EMA200
   - close below prior 40-bar low
   - volume ratio >= 0.80
   - stop: 2.5 ATR
   - target: 6.5 ATR
   - max hold: 42 x 4h = 168h / 7 days

Forward-only rules:
- A persistent `shadow_forward_epoch` is created once in SQLite/KV at first v2.0 startup.
- The epoch survives deploy/restart because it is stored in `/data/alpha_v1.db`.
- Signal bars must START after the epoch. Pre-epoch bars are never backfilled into the forward sample.
- The shadow lab uses completed Bitstamp 60m history only to calculate the frozen 4h/12h signal state.
- When a valid completed signal is detected, the shadow entry uses the current executable Kraken reference price, not a retroactive next-bar open.
- Shadow positions are marked every normal live-engine scan.
- Stop gaps use the observed adverse price; target exits are not granted a better-than-target fill.
- Shadow positions and trades are completely isolated from the live paper account.
- No real order route exists.

Persistent SQLite tables added:
- `shadow_signals`
- `shadow_positions`
- `shadow_trades`

Shadow cost overlays tracked on every closed trade:
- primary: `kraken_futures_t1_all_taker_funding5`
- diagnostic: `kraken_futures_t1_all_taker_funding1`
- diagnostic: `kraken_futures_t1_maker_entry_target_funding1`

Forward evidence state:
- `COLLECTING_FORWARD_EVIDENCE` until both minimum runtime and minimum closed trade sample are reached.
- Default minimum runtime: 30 days.
- Default minimum closed trades: 30.
- Default minimum per-strategy sample for strategy-level positive evidence: 15.
- `FORWARD_REVIEW_CANDIDATE` is only possible after the sample is mature and the primary harsh-cost results are positive with PF > 1.05, at least one individual strategy is positive, and closed trades span at least five symbols.
- `FORWARD_REVIEW_CANDIDATE` is a review flag only. It does NOT auto-promote anything to live execution.
- If the mature sample fails the checks, state becomes `FORWARD_EVIDENCE_WEAK`.

New endpoints:
- `/api/shadow-forward`
- `/api/shadow-positions`
- `/api/shadow-trades`

Dashboard:
- New section: `v2.0 Shadow Forward Lab — future data only`
- Shows persistent epoch, runtime, no-backfill status, signal count, open/closed shadow positions, primary Avg R/PF, evidence state, per-strategy results, open shadow positions and recent closed trades.

Live engine:
- unchanged from v1.9
- PAPER ONLY
- long-only live paper engine remains isolated
- shadow shorts are simulated/research only
- no real-money order route

Local validation before deployment:
- Python syntax: passed
- import: passed
- shadow endpoints present
- persistent shadow tables created correctly
- epoch persistence logic works
- frozen 12h and 4h signal matchers tested
- synthetic shadow open/close tested
- gross R and all three cost overlays produced finite values
- initial evidence state correctly reports `COLLECTING_FORWARD_EVIDENCE`

Next deployment steps:
1. Upload `alpha_v2_0_ready.py` to GitHub and rename it exactly `app.py`.
2. Verify APP_VERSION is `Alpha v2.0 — Shadow Forward Lab + Persistent OOS Evidence`.
3. Open dashboard:
   https://web-production-16997.up.railway.app/
4. Confirm the v2.0 shadow section shows a persistent epoch and `No backfill = YES`.
5. After this deployment, do NOT reset `/data/alpha_v1.db`, because that database now contains the forward-test epoch and accumulated shadow evidence.
6. Future versions must preserve the shadow tables and epoch unless a deliberate new preregistered experiment is started.

Important interpretation:
- No immediate result is expected from v2.0. A blank/zero-trade shadow section immediately after deployment is correct.
- The value of v2.0 is that future signals are now recorded without historical re-selection.
- Historical v1.9 results are hypotheses; v2.0 is the actual prospective test.

---

## 19. CURRENT BUILD — ALPHA v2.0 SHADOW FORWARD LAB

Current build:
**Alpha v2.0 — Shadow Forward Lab**

Reason for v2.0:
- v1.9 found the first historically interesting low-turnover short-breakout candidates, but they did not pass aggregate walk-forward validation.
- Rather than add more parameter search, v2.0 freezes two rules and collects genuinely forward-only unseen evidence from deployment onward.

Frozen shadow strategies:
1. `shadow_12h_breakout20_short`
   - derived from v1.9 `exec_12h_breakout20_short`
   - 12h bars
   - short only
   - EMA20 < EMA50 < EMA200
   - close below prior 20-bar low
   - stop 2.5 ATR
   - target 7.0 ATR
   - max hold 20 x 12h = 240h

2. `shadow_4h_breakout40_short`
   - derived from v1.9 `exec_4h_breakout40_short`
   - 4h bars
   - short only
   - EMA20 < EMA50 < EMA200
   - close below prior 40-bar low
   - volume ratio >= 0.80
   - stop 2.5 ATR
   - target 6.5 ATR
   - max hold 42 x 4h = 168h

Forward-only protections:
- Persistent `shadow_forward_start_ts` is created on first v2.0 startup.
- Signal bars that completed before the v2.0 start timestamp are ignored.
- There is no historical backfill of shadow trades.
- Strategy parameters are frozen in code.
- One shadow position per strategy/symbol.
- Shadow results are isolated from the main paper account.
- No live order route, no real-money route, no live short route.

Persistent SQLite additions:
- `shadow_signals`
- `shadow_positions`
- `shadow_trades`

Shadow execution model:
- Current market price is used as the raw shadow entry/exit reference.
- Primary evidence cost profile: `kraken_futures_t1_all_taker_funding5`.
- Diagnostic cost profiles are recorded separately:
  - `kraken_futures_t1_all_taker_funding1`
  - `kraken_futures_t1_maker_entry_target_funding1`
- Maker-fill diagnostic cannot by itself promote a strategy.

Forward evidence states:
- `SHADOW_FORWARD_BUILDING` while sample is young/small.
- After at least 28 days AND 50 closed forward trades:
  - `SHADOW_FORWARD_PROMISING` only if Avg R > 0 and PF > 1.05.
  - otherwise `SHADOW_FORWARD_NOT_CONFIRMED`.
- These labels are research diagnostics only and do not activate real trading.

Runtime behavior:
- Position marks/stop/target/time management approximately every 60 seconds.
- Expensive deep-history signal scans are aligned to completed 4h UTC boundaries.
- 120d of 60m Bitstamp history is used to construct 4h/12h indicators for current forward signal detection.

New endpoint:
- `/api/shadow-forward`

Dashboard adds:
- v2.0 Shadow Forward Lab — unseen data only
- forward age
- open shadow positions
- closed forward trades
- Avg R / PF / Total R
- frozen strategy breakdown
- open shadow positions and recent shadow trades

Local validation before deployment:
- Python syntax passed.
- Import passed using an isolated temporary SQLite database.
- New persistent shadow tables created successfully.
- `/api/shadow-forward` route present.
- Forward start timestamp persisted.
- Initial state correctly reports zero backfilled trades and `SHADOW_FORWARD_BUILDING`.

Latest v1.9 real result that motivated v2.0:
- 365d execution research completed.
- 11/12 deep markets.
- 1,677 raw trades / 8,385 paired rows across 5 identical-entry cost profiles.
- Cost pairing EXACT.
- Historical clue: `exec_4h_breakout40_short` remained positive in the harsh futures funding-stress full sample.
- Macro breakout family was the best primary-cost family full sample.
- But 5-fold execution WFO failed overall:
  - 230 OOS trades
  - Avg R -0.355
  - PF 0.49
  - Total -81.65R
  - 1/5 profitable folds
- Macro breakout OOS was closest to breakeven but still negative:
  - 58 trades
  - Avg R -0.0318
  - PF 0.936
  - Total -1.85R
- Therefore v1.9 verdict remained `NO_ROBUST_EXECUTION_EDGE_YET`.

Next action after v2.0 deployment:
1. Verify APP_VERSION is exactly `Alpha v2.0 — Shadow Forward Lab`.
2. Confirm dashboard stays healthy.
3. Do NOT judge performance immediately; the point is forward accumulation.
4. Check `/api/shadow-forward` or dashboard occasionally.
5. Preserve the persistent Railway volume so shadow history survives redeploys/restarts.
6. Do not modify the frozen shadow rules while the forward test is running; changing them would contaminate the experiment.
---

## 22. CURRENT BUILD — ALPHA v2.1 PARALLEL RESEARCH + SHADOW FORWARD

Current deploy-ready file:
`app.py`

Version header:
**Alpha v2.1 — Parallel Research + Shadow Forward**

Reason for v2.1:
- v2.0 forward-only collection remains methodologically necessary, but waiting passively would make the development cycle too slow.
- v2.1 keeps the original v2.0 forward epoch, frozen strategies and persistent shadow ledger unchanged.
- It adds immediate, report-only robustness diagnostics that run automatically after the v1.9 execution-history trades are rebuilt.
- No live-order route was added. The main long-only paper engine and all risk controls remain unchanged.

New parallel diagnostics for the two frozen hypotheses:
- `exec_12h_breakout20_short`
- `exec_4h_breakout40_short`

For each strategy v2.1 reports:
- conservative primary-cost performance;
- performance by individual market;
- positive-market breadth;
- six chronological stability slices;
- performance under all five existing spot/futures cost profiles;
- deterministic 2,000-iteration bootstrap using 30-day calendar blocks;
- bootstrap 5th/50th/95th percentiles for Avg R;
- estimated percentage of bootstrap samples with positive Avg R;
- a strict rapid-robustness checklist and gate.

Rapid robustness checks:
- at least 50 trades;
- positive Avg R under the harsh primary futures cost profile;
- PF > 1.10;
- at least 60% positive market breadth among markets with at least 3 trades;
- at least 4 of 6 positive chronological slices;
- positive bootstrap 5th percentile.

Possible rapid gate:
`RAPID_ROBUSTNESS_CANDIDATE`

Otherwise:
`NOT_RAPIDLY_ROBUST`

Overall section gate:
- `PARALLEL_CANDIDATE_FOUND`, or
- `NO_PARALLEL_ROBUSTNESS_YET`.

Important interpretation:
- The parallel lab shortens iteration time and helps reject fragile strategies quickly.
- It does not turn historical data into genuine future data and does not replace the v2.0 shadow-forward evidence.
- Shadow data continues accumulating in parallel rather than blocking continued research.

New endpoint:
`/api/parallel-lab`

New dashboard section:
`v2.1 Parallel Robustness Lab — immediate diagnostics`

Validation completed before delivery:
- Python syntax compile: PASS
- full module import with Railway dependencies: PASS
- `/api/parallel-lab` route: PASS
- deterministic bootstrap: PASS
- two frozen strategy reports: PASS
- six chronological slices per strategy: PASS
- dashboard JavaScript syntax: PASS
- synthetic positive-candidate dry-run: PASS
- source SHA-256: `f87ef21b88315fd57050f952bf9cdfa62799547c729161b4fd7e07178fa6c2f4`

Next deployment action:
1. Replace GitHub `app.py` with the v2.1 `app.py`.
2. Do not delete or reset `/data/alpha_v1.db`.
3. Verify the dashboard header reads `Alpha v2.1 — Parallel Research + Shadow Forward`.
4. Allow the historical pipeline to complete; the parallel lab runs automatically after v1.9 execution-edge reconstruction.
5. Inspect `/api/parallel-lab` or the new dashboard section.

Latest operating snapshot before v2.1 deployment:
- v2.0 shadow forward running with no shadow trade yet;
- 10 closed live-paper trades;
- realized P&L about +$58.52;
- 6 open live-paper positions;
- heat about 1.201%;
- no real-money route.

---

## 19. CURRENT BUILD — ALPHA v2.2 REGIME-AWARE BREAKOUT LAB

Current delivery file: `alpha_v2_2_ready.py` (rename to `app.py` in GitHub).

v2.1 completed its parallel robustness analysis. Neither frozen strategy passed the rapid gate.
The strongest lead remained `exec_4h_breakout40_short`: 191 trades, Avg R +0.1095,
PF 1.198, +20.92R and 9/11 positive eligible markets under the harsh futures cost profile.
It failed because only 3/6 chronological slices were positive, max drawdown was 36R and
the deterministic block-bootstrap 5th percentile remained negative. The 12h candidate was weaker.

v2.2 adds a report-only, causal regime lab. It does not modify the paper engine or the existing
v2.0 shadow cohort. It evaluates ten fixed signal-time filters for each frozen strategy, using only
information known at the close of the signal bar: local ATR/price, EMA trend depth, distance below
EMA200, RSI, volume ratio, recent returns and aligned Bitcoin trend/momentum state.

Validation design:
- harsh primary cost remains `kraken_futures_t1_all_taker_funding5`;
- 20 fixed strategy/filter hypotheses, not an unconstrained parameter search;
- five expanding outer walk-forward folds;
- selection occurs on each fold's training history only;
- chosen rule is then evaluated on the untouched next fold;
- deterministic 30-day calendar-block bootstrap on combined OOS trades;
- full-sample rankings are diagnostics only and cannot promote a candidate.

Promotion gate `REGIME_EDGE_CANDIDATE` requires all of:
- at least 50 OOS trades;
- positive OOS Avg R;
- OOS PF > 1.20;
- at least 4/5 profitable OOS folds;
- bootstrap probability of positive mean >= 80%;
- positive bootstrap 5th percentile.

New endpoint: `/api/regime-lab`.
New dashboard section: `v2.2 Regime-Aware Breakout Lab — causal walk-forward`.

The dashboard also reports simple risk-sizing scenarios at 0.25%, 0.50% and 1.00% risk per trade.
These are historical arithmetic projections, not forecasts or permission to increase paper/live risk.

Safety continuity verified:
- Shadow strategy definitions unchanged;
- Shadow strategy hash unchanged: `d3ec434f5e420d97`;
- existing shadow epoch/ledger remains persistent in `/data/alpha_v1.db`;
- no live-money order route exists;
- regime lab is research/report-only.

v2.2 validation completed before delivery:
- Python syntax compile: PASS;
- full module import: PASS;
- `/api/regime-lab` route: PASS;
- dashboard rendering function: PASS;
- five-fold synthetic regime-lab dry-run: PASS;
- source SHA-256: `8bb2dbea1b435f5e489fb775a5b38c29b76307f65329ce60b960aecf8f54406c`.

Deployment:
1. Replace GitHub `app.py` with `alpha_v2_2_ready.py`, renamed exactly `app.py`.
2. Never delete or reset `/data/alpha_v1.db`.
3. Confirm the header reads `Alpha v2.2 — Regime-Aware Breakout Lab`.
4. Wait for the historical execution pipeline to finish (minutes, not weeks).
5. Read `/api/regime-lab`; do not promote anything unless the strict gate passes.

---

## 20. CURRENT BUILD — ALPHA v2.3 DIVERSIFIED EDGE LAB

v2.2 completed with `NO_REGIME_EDGE_YET`. Although the full-sample combination
`exec_4h_breakout40_short + btc_strong_down` showed 142 trades, Avg R +0.2508,
PF 1.494 and +35.61R, its outer walk-forward failed: 87 OOS trades, Avg R -0.0623,
PF 0.895, -5.42R, only 1/5 profitable folds and 40.1% bootstrap probability of
a positive mean. Therefore no regime-filtered breakout was promoted.

v2.3 stops adding filters to that breakout family and creates a separate report-only
diversification laboratory with three structurally different families:

1. `cross_sectional_momentum`: 12h top/bottom relative performers, long and short;
2. `relative_mean_reversion`: 4h extreme relative winner/laggard reversal with RSI exhaustion;
3. `time_series_trend`: 12h directional trend following without a Donchian breakout.

All signals use completed signal bars only. Raw signals/exits are created once and then
expanded across all five v1.9 cost profiles with an exact same-entry pairing audit. The
evidence gate uses the harsh all-taker futures + 5bp funding/8h profile.

The five-fold expanding outer walk-forward selects at most two candidates from distinct
families using training data only. Gate `DIVERSIFIED_EDGE_CANDIDATE` requires:
- at least 75 OOS trades;
- positive OOS Avg R;
- OOS PF > 1.15;
- at least 3/5 profitable folds;
- at least 75% block-bootstrap probability of positive mean;
- at least two selected families.

New endpoint: `/api/diversified-lab`.
New dashboard section: `v2.3 Diversified Edge Lab — independent families`.

Safety continuity:
- report-only laboratory;
- paper strategy unchanged;
- existing v2.0 Shadow Forward definitions and epoch unchanged;
- Shadow hash unchanged: `d3ec434f5e420d97`;
- no real-money route.

Validation before delivery:
- Python compile and full import: PASS;
- 11-market synthetic full laboratory: PASS;
- 1,248 raw synthetic trades / 6,240 paired cost rows: PASS;
- exact cost pairing: PASS;
- all five outer folds: PASS;
- endpoint and dashboard: PASS.

Deployment:
1. Replace GitHub `app.py` with `alpha_v2_3_ready.py`, renamed exactly `app.py`.
2. Never delete or reset `/data/alpha_v1.db`.
3. Confirm `Alpha v2.3 — Diversified Edge Lab` in `/health` and the dashboard.
4. Allow the historical pipeline to complete and inspect `/api/diversified-lab`.

---

## 21. CURRENT BUILD — ALPHA v2.4 DERIVATIVES INTELLIGENCE LAB

v2.3 produced interesting full-sample results but failed its causal outer walk-forward:
236 OOS trades, Avg R -0.0391, PF 0.912, -9.23R and 2/5 profitable folds.
The project therefore stops expanding price/volume-only variants and begins collecting
independent derivatives and microstructure features.

v2.4 adds an isolated, persistent, forward-only collector for 12 Kraken markets. Every
five minutes it attempts to store spot top-of-book/depth and public perpetual-futures
data, including mark/index price, open interest, funding, predicted funding, spot-futures
basis, spread and 25-level order-book imbalance. Missing exchange fields remain null and
reduce the explicit quality score; they are never imputed or invented.

New persistent table: `derivatives_snapshots`.
New endpoints:
- `/api/derivatives-intelligence`
- `/api/derivatives-snapshots`

The initial causal-test gate requires at least 24 hours, 1,000 snapshots and at least
70% coverage for basis and order-book data. This is an initial research-readiness gate,
not proof of an edge. The collector is observational only and cannot alter paper or
shadow decisions.

Safety continuity verified:
- paper strategy and risk controls unchanged;
- Shadow definitions, epoch handling and ledger unchanged;
- Shadow hash unchanged: `d3ec434f5e420d97`;
- database remains `/data/alpha_v1.db`;
- no live-money order route exists.

Validation before delivery:
- Python compile and AST parse: PASS;
- full import in the project environment: PASS;
- SQLite migration, snapshot insert and summary API: PASS;
- forward evidence gate and feature coverage math: PASS;
- Shadow hash regression assertion: PASS.

Deployment:
1. Replace GitHub `app.py` with `alpha_v2_4_ready.py`, renamed exactly `app.py`.
2. Never delete or reset `/data/alpha_v1.db`.
3. Confirm `/health` reports `Alpha v2.4 — Derivatives Intelligence Lab`.
4. Confirm `/api/derivatives-intelligence` begins increasing `samples` immediately.

---

## 22. CURRENT BUILD — ALPHA v2.5 CAUSAL MICROSTRUCTURE LAB

v2.4 reached its initial research-readiness gate with 3,600 forward-only observations,
25+ hours of coverage, 12/12 markets and 100% feature quality/coverage.

v2.5 consumes the persistent `derivatives_snapshots` dataset without altering the live
paper engine or Shadow Forward. It tests five fixed hypotheses at 1h and 4h horizons:
funding contrarian, predicted-funding contrarian, basis contrarian, order-book imbalance
momentum and OI/price confirmation.

Methodology:
- future returns are built only from observations occurring after each signal;
- entries are non-overlapping at each horizon;
- long/short selection uses cross-sectional ranks across the 12 markets;
- cost model is 5bp fee + 3bp slippage per side, plus 5bp/8h funding stress;
- two chronological expanding folds select on training only;
- the maximum horizon is purged before each test boundary to prevent label leakage;
- full-sample winners remain diagnostics and never change trading rules.

New endpoint: `/api/microstructure-lab`.
New dashboard section: `v2.5 Causal Microstructure Lab`.

Safety continuity verified:
- paper execution rules unchanged;
- Shadow definitions and epoch unchanged;
- Shadow hash unchanged: `d3ec434f5e420d97`;
- persistent database remains `/data/alpha_v1.db`;
- no live-money route exists.

Validation before delivery:
- Python compile: PASS;
- full import and SQLite migration: PASS;
- real Kraken forward-snapshot dry-run: PASS;
- 10 fixed candidate/horizon combinations: PASS;
- two purged chronological folds: PASS;
- insufficient-sample apparent winners rejected: PASS;
- Shadow hash regression assertion: PASS.

Deployment:
1. Replace GitHub `app.py` with `alpha_v2_5_ready.py`, renamed exactly `app.py`.
2. Never delete or reset `/data/alpha_v1.db`.
3. Confirm `/health` reports `Alpha v2.5 — Causal Microstructure Lab`.
4. Wait approximately 25 seconds and inspect `/api/microstructure-lab`.
